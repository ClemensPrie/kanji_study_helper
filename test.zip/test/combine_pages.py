"""Combine kanji_study_guide.html and vocab_by_jlpt.html into a single tabbed index.html.

Creates a PWA-ready page that can be added to phone homescreen.
"""

import re
from pathlib import Path


def extract_body_content(html: str) -> str:
    """Extract content between <body> tags, excluding the tags themselves."""
    match = re.search(r'<body[^>]*>(.*?)</body>', html, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else ''


def extract_styles(html: str) -> str:
    """Extract all <style> content from the HTML."""
    styles = re.findall(r'<style[^>]*>(.*?)</style>', html, re.DOTALL | re.IGNORECASE)
    return '\n'.join(styles)


def extract_scripts(html: str) -> str:
    """Extract all <script> content from the HTML."""
    scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL | re.IGNORECASE)
    return '\n'.join(scripts)


def create_combined_html():
    # Read both HTML files
    kanji_html = Path('kanji_study_guide.html').read_text(encoding='utf-8')
    vocab_html = Path('vocab_by_jlpt.html').read_text(encoding='utf-8')
    
    # Extract body content (without <script> tags)
    kanji_body = extract_body_content(kanji_html)
    vocab_body = extract_body_content(vocab_html)
    
    # Remove script tags from body content (we'll handle scripts separately)
    kanji_body_clean = re.sub(r'<script[^>]*>.*?</script>', '', kanji_body, flags=re.DOTALL)
    vocab_body_clean = re.sub(r'<script[^>]*>.*?</script>', '', vocab_body, flags=re.DOTALL)
    
    # Extract styles and scripts
    kanji_styles = extract_styles(kanji_html)
    vocab_styles = extract_styles(vocab_html)
    kanji_scripts = extract_scripts(kanji_html)
    vocab_scripts = extract_scripts(vocab_html)
    
    combined_html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Japanese Study Guide</title>
    
    <!-- PWA Meta Tags -->
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="日本語">
    <link rel="apple-touch-icon" href="icon.svg">
    
    <style>
        /* Tab Navigation Styles */
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #f5f5f5;
            color: #333;
        }}
        
        .tab-container {{
            position: sticky;
            top: 0;
            z-index: 1000;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 12px 16px;
            display: flex;
            gap: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }}
        
        .tab-btn {{
            flex: 1;
            padding: 12px 16px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            background: rgba(255,255,255,0.2);
            color: white;
        }}
        
        .tab-btn:hover {{
            background: rgba(255,255,255,0.3);
        }}
        
        .tab-btn.active {{
            background: white;
            color: #667eea;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        
        .tab-content {{
            display: none;
            padding: 16px;
        }}
        
        .tab-content.active {{
            display: block;
        }}
        
        .tab-content .container {{
            max-width: 700px;
            margin: 0 auto;
        }}
        
        /* Scoped styles from kanji page */
        #kanji-tab {{
            {kanji_styles}
        }}
        
        /* Scoped styles from vocab page */
        #vocab-tab {{
            {vocab_styles}
        }}
        
        /* Override container padding since we have it on tab-content */
        .tab-content .container {{
            padding: 0;
        }}
        
        @media (max-width: 480px) {{
            .tab-btn {{
                font-size: 12px;
                padding: 10px 8px;
            }}
            .tab-content {{
                padding: 12px;
            }}
        }}
    </style>
</head>
<body>
    <!-- Tab Navigation -->
    <div class="tab-container">
        <button class="tab-btn active" onclick="showTab('kanji')">📚 Kanji Study</button>
        <button class="tab-btn" onclick="showTab('vocab')">📖 Vocabulary</button>
    </div>
    
    <!-- Kanji Study Guide Tab -->
    <div id="kanji-tab" class="tab-content active">
        {kanji_body_clean}
    </div>
    
    <!-- Vocabulary Tab -->
    <div id="vocab-tab" class="tab-content">
        {vocab_body_clean}
    </div>
    
    <script>
        // Tab switching
        function showTab(tabName) {{
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {{
                tab.classList.remove('active');
            }});
            document.querySelectorAll('.tab-btn').forEach(btn => {{
                btn.classList.remove('active');
            }});
            
            // Show selected tab
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
            
            // Scroll to top when switching tabs
            window.scrollTo(0, 0);
        }}
        
        // Kanji page scripts
        (function() {{
            {kanji_scripts}
        }})();
        
        // Vocab page scripts
        (function() {{
            {vocab_scripts}
        }})();
        
        // Register service worker for PWA
        if ('serviceWorker' in navigator) {{
            navigator.serviceWorker.register('sw.js')
                .then(reg => console.log('Service Worker registered'))
                .catch(err => console.log('Service Worker registration failed:', err));
        }}
    </script>
</body>
</html>
'''
    
    # Write the combined HTML
    Path('index.html').write_text(combined_html, encoding='utf-8')
    
    print("✅ Created index.html")
    print("   - Combined kanji_study_guide.html and vocab_by_jlpt.html")
    print("   - Added tab navigation")
    print("   - Added PWA manifest & service worker registration")
    print("   - Ready for GitHub Pages!")
    print("")
    print("📱 To add to phone homescreen:")
    print("   iOS: Share → Add to Home Screen")
    print("   Android: Menu → Add to Home Screen")


if __name__ == "__main__":
    create_combined_html()
